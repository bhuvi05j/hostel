// const sequelize = require("../config/database");
// const create_room=require("./create_room");
// const{create_room}=required('./config/database');
// Syunchronized
// sequelize.sync()
//    .then(()=>{
//     console.log('all tables synchronised');
// })
// .catch((err)=>{
//     console.error('error synchronizedd',err);
// })
const create_room=require("./create_room");
module.exports=
{create_room}