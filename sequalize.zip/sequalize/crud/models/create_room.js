const { DataTypes } = require("sequelize");
const sequelize = require('../config/database');

const CreateRoom = sequelize.define("create_room", {
    room_no: {
        type: DataTypes.INTEGER,
    },
    room_type: {
        type: DataTypes.INTEGER,
    },
    
    hostel_name:
    {   
        type:DataTypes.STRING,
    }
    
});

// Export the model
module.exports = CreateRoom;
