const { DataTypes } = require("sequelize");
const sequelize = require('../config/database');

const Createhostel = sequelize.define("create_hostel", {
    hostel_name: {
        type: DataTypes.STRING,
    },
    hostel_type: {
        type: DataTypes.ENUM('pg','school','college'),
    },
    
    room_number:
    {   
        type:DataTypes.INTEGER,
    }
    
});

// Export the model
module.exports = Createhostel;
