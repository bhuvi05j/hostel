const  Sequelize  = require("sequelize");
const sequelize = new Sequelize("hostel_management", "root", "bhuvi", {
    dialect: "mysql",
  });

  sequelize
  .authenticate()
  .then(() => {
    console.log("Connection made successful");
  })
  .catch((err) => {
    console.error("Unable to connect to the database:", err);
  });

  module.exports=sequelize