
const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cors = require('cors');
const sequelize = require('../crud/config/database');
const userRoutes = require("./routes/cretae_room_routes");
const userRoutess = require("./routes/crteate_hostel_router");

// Syncing models with the database
sequelize.sync().then(() => {
  console.log('All models were synchronized successfully.');
}).catch(err => {
  console.error('Unable to synchronize models:', err);
});

// Configure middleware
app.use(cors({
  origin: 'http://localhost:3000',
  optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Define routes
app.use("/api", userRoutes);
app.use("/api", userRoutess);

const port = 7000;

// Start the server
app.listen(port, () => {
  console.log(`Server connected at the port ${port}`);
});





