# CRUD-Operation-Using-MY-SQL
CRUD operations with MYSQL using sequelize
