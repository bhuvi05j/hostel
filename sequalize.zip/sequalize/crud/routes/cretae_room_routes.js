 const express=require("express")
 const router=express.Router();
    const create_room_controller=require('../controllers/create_room_controller')
router.post("/users",create_room_controller.allocate_room);
router.get("/users",create_room_controller.get_rooms);
router.get("/users/:id",create_room_controller.getById);
router.get("/users/:id",create_room_controller.updateById);
module.exports=router;
