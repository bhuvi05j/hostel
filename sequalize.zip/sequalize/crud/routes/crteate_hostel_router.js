const express=require("express")
 const router=express.Router();
    const create_hostel_controller=require('../controllers/create_hostel_controller')
router.post("/hostel",create_hostel_controller.get_hostel);
router.get("/hostel",create_hostel_controller.getall_hostel);
router.get("/hostel/:id",create_hostel_controller.getById_hostel);
router.get("/hostel/:id",create_hostel_controller.updateById_hostel);
router.get("/hostel/:id",create_hostel_controller.deleteByID_hostel);
module.exports=router;
