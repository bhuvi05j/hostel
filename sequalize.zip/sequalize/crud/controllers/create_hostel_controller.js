const create_hostel = require('../models/create_hostel');

async function get_hostel(req, res) {
    try {
        const { hostel_name, hostel_type, room_number } = req.body;
        const hostel = await create_hostel.create({ hostel_name, hostel_type, room_number });
        res.status(200).json(hostel);
    } catch (err) {
        console.error('error creating hostel:', err);
        res.status(500).json({ error: 'internal server error' });
    }
}

async function getall_hostel (req, res) {
    try {
        const hostel = await create_hostel.findAll();
        res.status(200).json(hostel);
    } catch (err) {
        console.error('error fetching rooms:', err);
        res.status(500).json({ error: 'internal server error' });
    }
}

async function getById_hostel(req, res) {
    const hostelId = req.params.id;
    try {
        const hostel = await create_hostel.findByPk(hostelId);
        if (!hostel) {
            res.status(404).json({ error: "room not found" });
        } else {
            res.status(200).json(hostel);
        }
    } catch (err) {
        console.error('error fetching room:', err);
        res.status(500).json({ error: 'internal server error' });
    }
}

async function updateById_hostel(req, res) {
    const hostelId = req.params.id;
    try {
        let hostel = await create_hostel.findByPk(hostelId);
        if (!hostel) {
            res.status(404).json({ error: "room not found" });
        } else {
            const { hostel_name, hostel_type, room_number } = req.body;
            hostel = await create_hostel.update({ hostel_name, hostel_type, room_number });
            res.status(200).json(hostel);
        }
    } catch (err) {
        console.error('error updating room:', err);
        res.status(500).json({ error: 'internal server error' });
    }
}


async function deleteByID_hostel(req,res){
    const hostelId=req.params.id;
    try{
        const hostel=await room.findByPk(hostelId);
        if(!hostelId){
            res.send(404).json({error:"room not founnd"});

        }else{
            await hostel.destroy();
            res.status(204).end();

        }
        }catch(error){
            console.error("error deteting room",error);
            res.status(500).json({error:"internal server error"});
        }
    
}

module.exports = { get_hostel, getall_hostel, getById_hostel, updateById_hostel,deleteByID_hostel  };

