// const create_room=require('../models/create_room');
// async function define_room(req,res){
//     try{
//         const{room_no,room_type,hostel_name}=req.body;
//         const create_room=await create_room.create({room_no,room_type,hostel_name})
//         res.status(200).json(create_room)
//     }catch(err){
//         console.error('error creating user:',err);
//          res.status(500).json({error:'interrnal server error'});
        
//     }
// }

// async function get_room(req,res){
//     try{
//         const users=await user.findAll();
//         res.status(200).json(users)
//     }catch(err){
//         console.error('error creating user:',err);
//          res.status(500).json({error:'interrnal server error'});
        
//     }
// }

// async function getById(req,res){
//     const usersid=req.params.id
//     try{
//         const user=await user.findBYPk(usersid);
//             if(!user){
//                 res.status(404).json({error:"user not found"});
//             }
//             else{
//                 res.status(200).json(user);
//             }
       
//     }catch(err){
//         console.error('error creating user:',err);
//          res.status(500).json({error:'interrnal server error'});
        
//     }
// }

// async function udateById(req,res){
//     const usersid=req.params.id
//     try{
//         const user=await user.findBYPk(usersid);
//             if(!user){
//                 res.status(404).json({error:"user not found"});
//             }
//             else{
//                 const{room_number,room_type_,hostel_name}=req.body;
//                 user.room_number=room_number,
//                 user.room_type=room_type,
//                 user.hostel_name=hostel_name
//                 await user.save()
//                 res.status(200).json(user);
//             }
       
//     }catch(err){
//         console.error('error creating user:',err);
//          res.status(500).json({error:'interrnal server error'});
        
//     }
// }

// module.exports={define_room,get_room,getById,udateById};


const create_room = require('../models/create_room');

async function allocate_room(req, res) {
    try {
        const { room_no, room_type, hostel_name } = req.body;
        const room = await create_room.create({ room_no, room_type, hostel_name });
        res.status(200).json(room);
    } catch (err) {
        console.error('error creating room:', err);
        res.status(500).json({ error: 'internal server error' });
    }
}

async function get_rooms(req, res) {
    try {
        const rooms = await create_room.findAll();
        res.status(200).json(rooms);
    } catch (err) {
        console.error('error fetching rooms:', err);
        res.status(500).json({ error: 'internal server error' });
    }
}

async function getById(req, res) {
    const roomId = req.params.id;
    try {
        const room = await create_room.findByPk(roomId);
        if (!room) {
            res.status(404).json({ error: "room not found" });
        } else {
            res.status(200).json(room);
        }
    } catch (err) {
        console.error('error fetching room:', err);
        res.status(500).json({ error: 'internal server error' });
    }
}

async function updateById(req, res) {
    const roomId = req.params.id;
    try {
        let room = await create_room.findByPk(roomId);
        if (!room) {
            res.status(404).json({ error: "room not found" });
        } else {
            const { room_number, room_type, hostel_name } = req.body;
            room = await room.update({ room_number, room_type, hostel_name });
            res.status(200).json(room);
        }
    } catch (err) {
        console.error('error updating room:', err);
        res.status(500).json({ error: 'internal server error' });
    }
}


async function deleteByID(reqw,res){
    const room_id=req.params.id;
    try{
        const room=await room.findByPk(room_id);
        if(!room_id){
            res.send(404).json({error:"room not founnd"});

        }else{
            await room.destroy();
            res.status(204).end();

        }
        }catch(error){
            console.error("error deteting room",error);
            res.status(500).json({error:"internal server error"});
        }
    
}

module.exports = { allocate_room, get_rooms, getById, updateById,deleteByID  };

